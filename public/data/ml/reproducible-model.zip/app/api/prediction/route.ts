import {createFireOutlook} from '@/lib/fire-outlook';
import type {FireOutlook} from '@/lib/fire-outlook-types';
import {parsePredictionLocation} from '@/lib/prediction-inputs';
const cache=new Map<string,{at:number;data:FireOutlook}>();
const pending=new Map<string,Promise<FireOutlook>>();
export async function GET(request:Request){
 const point=parsePredictionLocation(new URL(request.url).searchParams);if(!point)return Response.json({error:'Provide valid U.S. latitude and longitude.'},{status:400});
 const now=new Date(),key=`${now.toISOString().slice(0,10)}/${now.getUTCHours()<6?'pre06':'post06'}/${point.lat.toFixed(4)},${point.lon.toFixed(4)}`,previous=cache.get(key);
 if(previous&&Date.now()-previous.at<10*60000)return Response.json(previous.data,{headers:{'Cache-Control':'private,max-age=60'}});
 try{let task=pending.get(key);if(!task){if(pending.size>=4)return Response.json({error:'Several outlooks are being calculated. Try again shortly.'},{status:429});task=createFireOutlook(point.lat,point.lon);pending.set(key,task);}
   const data=await task;if(cache.size>=12)cache.delete(cache.keys().next().value!);cache.set(key,{at:Date.now(),data});return Response.json(data,{headers:{'Cache-Control':'private,max-age=60'}});
 }catch(error){return Response.json({error:error instanceof Error?error.message:'Outlook unavailable.'},{status:503});}
 finally{pending.delete(key);}
}
