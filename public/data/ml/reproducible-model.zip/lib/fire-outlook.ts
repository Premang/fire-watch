import fitted from '@/public/data/ml/model.json';
import {parseFirmsCsv,type FirePoint} from './fire-analysis';
import {stateForPoint} from './geography';
import {fetchPredictionInputs,type GridmetGrid,type GridmetCode} from './prediction-inputs';
import {fromUtm,toUtm,makeFireFeatures,outlookDates,predictFire,type FittedFireModel} from './fire-predictor';
import type {FireOutlook} from './fire-outlook-types';
import {fetchElevationGrid} from './prediction-terrain';
import {checkSnppSourceHealth} from './satellite-source-health';
import {priorContextPadding} from './fire-prior-context';

// The JSON tuple length and model hash are checked by release/parity tests.
const model=fitted as unknown as FittedFireModel;
const NASA='https://firms.modaps.eosdis.nasa.gov/data/active_fire/suomi-npp-viirs-c2/csv/SUOMI_VIIRS_C2_USA_contiguous_and_Hawaii_7d.csv';
const DAY=86400000,N=33,CELL=1500;
const SNPP_DELIVERY_END=Date.parse('2026-11-02T13:00:00Z');
const day=(at:number)=>new Date(at).toISOString().slice(0,10);
const finite=(x:unknown):x is number=>typeof x==='number'&&Number.isFinite(x);
const errorText=(e:unknown)=>e instanceof Error?e.message:'Source unavailable';

/** Stream and spatially filter before CSV parsing to bound Worker memory. */
async function fireHistory(bounds:{west:number;south:number;east:number;north:number},dates:ReturnType<typeof outlookDates>){
 const response=await fetch(NASA,{signal:AbortSignal.timeout(20000)});if(!response.ok||!response.body)throw new Error(`S-NPP source returned HTTP${response.status}`);
 const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',header='',indexes:Record<string,number>={},bytes=0,latest:string|null=null;
 const retained:string[]=[],national:Record<string,number>={};
 function line(text:string){if(!text.trim())return;if(!header){header=text;const fields=text.trim().split(',');indexes=Object.fromEntries(fields.map((s,i)=>[s,i]));for(const k of ['latitude','longitude','acq_date','acq_time','confidence'])if(indexes[k]===undefined)throw new Error('Unexpected S-NPP schema');return;}
   const v=text.split(','),date=v[indexes.acq_date];if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return;const hhmm=v[indexes.acq_time]?.padStart(4,'0');if(!/^(?:[01]\d|2[0-3])[0-5]\d$/.test(hhmm))return;const stamp=`${date}T${hhmm.slice(0,2)}:${hhmm.slice(2,4)}:00Z`;
   const lat=Number(v[indexes.latitude]),lon=Number(v[indexes.longitude]);if(!v[indexes.latitude]?.trim()||!v[indexes.longitude]?.trim()||!finite(lat)||!finite(lon)||Math.abs(lat)>90||Math.abs(lon)>180||!Number.isFinite(Date.parse(stamp))||new Date(stamp).toISOString().slice(0,10)!==date||Date.parse(stamp)>Date.now()+60000)return;
   if(!latest||stamp>latest)latest=stamp;
   national[date]=(national[date]??0)+1;
   if(date!==dates.recentFireDate&&date!==dates.priorFireDate)return;
   const confidence=v[indexes.confidence]?.trim().toLowerCase()??'';
   if(['l','low'].includes(confidence)||!finite(lat)||!finite(lon)||lat<bounds.south||lat>bounds.north||lon<bounds.west||lon>bounds.east)return;
   if(retained.length>=30000)throw new Error('Selected area exceeds the observation limit');retained.push(text);
 }
 try{for(;;){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>32_000_000)throw new Error('S-NPP feed exceeds the bounded processing limit');buffer+=decoder.decode(value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop()??'';for(const row of lines)line(row);}buffer+=decoder.decode();if(buffer)line(buffer);}catch(e){await reader.cancel().catch(()=>{});throw e;}
 const points=parseFirmsCsv([header,...retained].join('\n'),'VIIRS');return {points,national,lastModified:response.headers.get('last-modified'),latest};
}
function nearestGrid(grid:GridmetGrid|undefined,lat:number,lon:number):number|null{
 if(!grid)return null;const nearest=(v:number[],x:number)=>v.reduce((best,n,i)=>Math.abs(n-x)<Math.abs(v[best]-x)?i:best,0);
 const row=nearest(grid.latitudes,lat),col=nearest(grid.longitudes,lon);if(Math.abs(grid.latitudes[row]-lat)>.07||Math.abs(grid.longitudes[col]-lon)>.07)return null;return grid.values[row]?.[col]??null;
}
function fireMask(points:FirePoint[],date:string,zone:number,left:number,top:number){const mask=Array(N*N).fill(false) as boolean[];
 for(const p of points){if(p.acquiredAt.slice(0,10)!==date)continue;const v=toUtm(p.lat,p.lon,zone);
   // Same nominal375m footprint as WSTS, aggregated into1.5km cells.
   const minC=Math.floor((v.x-187.5-left)/CELL),maxC=Math.floor((v.x+187.5-left)/CELL),minR=Math.floor((top-(v.y+187.5))/CELL),maxR=Math.floor((top-(v.y-187.5))/CELL);
   for(let r=Math.max(0,minR);r<=Math.min(N-1,maxR);r++)for(let c=Math.max(0,minC);c<=Math.min(N-1,maxC);c++)mask[r*N+c]=true;
 }return mask;}

export async function createFireOutlook(lat:number,lon:number):Promise<FireOutlook>{
 const now=Date.now(),issueDate=day(now),dates=outlookDates(issueDate);
 const output:FireOutlook={schemaVersion:1,status:'abstained',modelId:model.id,fetchedAt:new Date(now).toISOString(),point:{lat,lon},...dates,cells:[],inputs:null,reasons:[],warnings:[
   'Research outlook of satellite-detected activity. Percentages are transferred model scores; current-condition calibration has not been established.',
   'Covers1.5km cells in a25.5km window around the selected location, within12km of recent S-NPP detections. It is not a fire perimeter or flame-arrival forecast.',
   'Live terrain uses USGS 3DEP cell-center samples instead of historical SRTM cell means. Native gridMET resampling differs from the training export. One GFS point represents the 25.5 km output window; its provider and derived humidity introduce unvalidated transfer differences.',
   'Open-Meteo applies elevation-based downscaling and terrain-optimized land-grid selection to GFS by default; these transformations differ from the historical inputs and have not been validated for this model.',
   'Cloud and overpass coverage are unknown. Missing detections do not prove extinguishment.',
   'Native PDSI uses a strictly earlier pentad label within five days, matching sampled historical cases. The original Earth Engine validity intervals are not exposed by this live service.',
   'NOAA plans to end S-NPP VIIRS delivery on November2,2026 at13:00UTC. This model will abstain; NOAA-20/21 need retraining and validation.',
 ],fireSource:null,satelliteHealth:null,featureCoverage:{completeCells:0,totalCells:0}};
 const state=stateForPoint(lon,lat);
 if(!state||state==='AK'||state==='HI'){output.reasons.push('This fitted pilot covers the contiguous United States only.');return output;}
 const center=toUtm(lat,lon),left=Math.floor(center.x/CELL)*CELL-16*CELL,top=Math.ceil(center.y/CELL)*CELL+16*CELL;
 const coords=Array.from({length:N*N},(_,i)=>fromUtm(left+(i%N+.5)*CELL,top-(Math.floor(i/N)+.5)*CELL,center.zone));
 const corners=[fromUtm(left,top,center.zone),fromUtm(left+N*CELL,top,center.zone),fromUtm(left,top-N*CELL,center.zone),fromUtm(left+N*CELL,top-N*CELL,center.zone)];
 const bounds={west:Math.min(...corners.map(p=>p[0])),east:Math.max(...corners.map(p=>p[0])),south:Math.min(...corners.map(p=>p[1])),north:Math.max(...corners.map(p=>p[1]))};
 // Derive satellite context from the released model. Terrain/recent neighborhoods
 // keep their bounded grid; the stream retains its byte and observation limits.
 const padding=priorContextPadding(model);
 const fireCorners=[fromUtm(left-padding*CELL,top+padding*CELL,center.zone),fromUtm(left+(N+padding)*CELL,top+padding*CELL,center.zone),fromUtm(left-padding*CELL,top-(N+padding)*CELL,center.zone),fromUtm(left+(N+padding)*CELL,top-(N+padding)*CELL,center.zone)];
 const fireBounds={west:Math.min(...fireCorners.map(p=>p[0])),east:Math.max(...fireCorners.map(p=>p[0])),south:Math.min(...fireCorners.map(p=>p[1])),north:Math.max(...fireCorners.map(p=>p[1]))};
 const [inputs,fire,health]=await Promise.allSettled([fetchPredictionInputs(lat,lon,{bounds}),fireHistory(fireBounds,dates),checkSnppSourceHealth([dates.recentFireDate,dates.priorFireDate])]);
 if(inputs.status==='fulfilled')output.inputs=inputs.value;else output.reasons.push(`Environmental data: ${errorText(inputs.reason)}`);
 if(health.status==='rejected')output.reasons.push(`S-NPP source health could not be checked: ${errorText(health.reason)}`);
 else{
   output.satelliteHealth=health.value;output.warnings.push(...health.value.warnings);
   if(health.value.status==='unavailable')output.reasons.push(`S-NPP source health is unavailable; known observation gaps cannot be checked. ${health.value.error??''}`.trim());
   else if(health.value.status==='reported-gap'){
     const intervals=health.value.overlappingOutages.slice(0,3).map(gap=>`${gap.start} to ${gap.end}`).join('; ');
     output.reasons.push(`A required S-NPP mask day overlaps ${health.value.overlappingOutages.length} NASA-reported outage interval(s): ${intervals}. Geographic impact is unknown; missing observations cannot be treated as zero activity.`);
   }
 }
 if(fire.status==='rejected')output.reasons.push(`Satellite history: ${errorText(fire.reason)}`);
 else{output.fireSource={url:NASA,lastModified:fire.value.lastModified,latestDetection:fire.value.latest,recentCount:fire.value.points.filter(p=>p.acquiredAt.startsWith(dates.recentFireDate)).length,priorCount:fire.value.points.filter(p=>p.acquiredAt.startsWith(dates.priorFireDate)).length,observationalCoverage:'unknown'};
   if(!fire.value.national[dates.recentFireDate]||!fire.value.national[dates.priorFireDate])output.reasons.push('A required S-NPP day has no source records; it cannot be treated as zero activity.');
   if(!fire.value.latest||now-Date.parse(fire.value.latest)>36*3600000)output.reasons.push('The S-NPP observation feed is stale.');
   if(output.fireSource.recentCount===0)output.reasons.push('No retained S-NPP detections yesterday in this area. The model has no existing-fire starting pattern.');
 }
 if(now>=SNPP_DELIVERY_END)output.reasons.push('S-NPP delivery has reached its announced end date. A model retrained for a continuing sensor is required.');
 else if(Date.parse(`${dates.targetDate}T00:00:00Z`)+DAY>SNPP_DELIVERY_END)output.reasons.push('The target UTC day crosses the announced S-NPP delivery end. A complete next-day detection target requires a model retrained for a continuing sensor.');
 if(now-Date.parse(`${issueDate}T00:00:00Z`)<6*3600000)output.reasons.push('The current00Z GFS run is not eligible until06:00UTC and successful retrieval.');
 const data=output.inputs,gfs=data?.gfs;
 if(!gfs||gfs.runInitializedAt.slice(0,10)!==issueDate||gfs.status!=='available')output.reasons.push('The required current-day00Z GFS run is unavailable; an older run is not substituted.');
 const codes:GridmetCode[]=['pr','tmmn','tmmx','sph','vs','th','erc','pdsi'];
 for(const code of codes){const grid=data?.gridmet.grids[code];if(!grid)output.reasons.push(`Required gridMET ${code} is unavailable.`);else if(code==='pdsi'?(Date.parse(dates.weatherDate)-Date.parse(grid.date)>5*DAY||Date.parse(grid.date)>=Date.parse(dates.weatherDate)):grid.date!==dates.weatherDate)output.reasons.push(`gridMET ${code} does not cover the required lagged date.`);}
 const antecedent=gfs?.antecedent;
 if(!antecedent||antecedent.forecastHourStart!==1||antecedent.forecastHourEnd!==24||antecedent.temperatureK===null||antecedent.specificHumidityKgKg===null||antecedent.vectorMeanWindSpeedMs===null)output.reasons.push('GFS F01–F24 has incomplete required forecast variables.');
 if(output.reasons.length||fire.status!=='fulfilled'||!data||!antecedent)return output;
 let elevations:(number|null)[];try{const terrainResult=await fetchElevationGrid(coords,`${center.zone}/${left}/${top}`);elevations=terrainResult.values;data.sources.push({id:'model-terrain',status:terrainResult.completeCount===terrainResult.totalCount?'available':'unavailable',url:terrainResult.source.url,fetchedAt:terrainResult.source.fetchedAt,sourceDate:terrainResult.source.acquisitionDates.join(', ')||null,warnings:[...terrainResult.source.warnings,terrainResult.source.provider+' / '+terrainResult.source.product, 'Sampling: '+terrainResult.source.sampling, 'Vertical datum: '+terrainResult.source.verticalDatums.join(', ')]});}catch(e){output.reasons.push(`Terrain grid: ${errorText(e)}`);return output;}
 const recent=fireMask(fire.value.points,dates.recentFireDate,center.zone,left,top),prior=fireMask(fire.value.points,dates.priorFireDate,center.zone,left,top);
 const priorCells:[number,number][]=[];
 const priorCellIds=new Set<string>();
 for(const p of fire.value.points){if(!p.acquiredAt.startsWith(dates.priorFireDate))continue;const v=toUtm(p.lat,p.lon,center.zone);for(let r=Math.floor((top-v.y-187.5)/CELL);r<=Math.floor((top-v.y+187.5)/CELL);r++)for(let c=Math.floor((v.x-left-187.5)/CELL);c<=Math.floor((v.x-left+187.5)/CELL);c++){const id=`${r}/${c}`;if(!priorCellIds.has(id)){priorCellIds.add(id);priorCells.push([r,c]);}}}
 for(let r=8;r<25;r++)for(let c=8;c<25;c++){
   const [cellLon,cellLat]=coords[r*N+c];if(!stateForPoint(cellLon,cellLat))continue;
   const v=(code:GridmetCode)=>nearestGrid(data.gridmet.grids[code],cellLat,cellLon);
   const f=makeFireFeatures(r,c,N,recent,prior,elevations,{precip:v('pr'),tmin:v('tmmn'),tmax:v('tmmx'),q:v('sph'),wind:v('vs'),direction:v('th'),erc:v('erc'),pdsi:v('pdsi')},{temperatureC:antecedent.temperatureK!-273.15,q:antecedent.specificHumidityKgKg,vectorWind:antecedent.vectorMeanWindSpeedMs});
   f[3]=priorCells.reduce((distance,[rr,cc])=>Math.min(distance,Math.hypot(r-rr,c-cc)*1.5),150);
   if((f[2]??150)>12)continue;output.featureCoverage.totalCells++;
   if(f.some(n=>!finite(n)))continue;output.featureCoverage.completeCells++;
   const polygon=[fromUtm(left+c*CELL,top-r*CELL,center.zone),fromUtm(left+(c+1)*CELL,top-r*CELL,center.zone),fromUtm(left+(c+1)*CELL,top-(r+1)*CELL,center.zone),fromUtm(left+c*CELL,top-(r+1)*CELL,center.zone)];polygon.push(polygon[0]);
   output.cells.push({id:`${r}-${c}`,polygon,p:predictFire(model,f),previous:+recent[r*N+c]});
 }
 if(!output.cells.length)output.reasons.push('No eligible cells with complete model inputs in this window.');
 else{output.status='experimental';if(output.featureCoverage.completeCells<output.featureCoverage.totalCells)output.warnings.push('Some cells have missing inputs and are omitted. Blank cells are unknown, not low risk.');}
 return output;
}
