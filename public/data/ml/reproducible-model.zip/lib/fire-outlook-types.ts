import type {PredictionInputs} from './prediction-inputs';
import type {OutlookCell} from './fire-predictor';
import type {SatelliteSourceHealth} from './satellite-source-health';
export type FireOutlook = {
 schemaVersion:1; status:'experimental'|'abstained'; modelId:string; fetchedAt:string; point:{lat:number;lon:number};
 issueDate:string;targetDate:string;recentFireDate:string;priorFireDate:string;weatherDate:string;
 cells:OutlookCell[]; inputs:PredictionInputs|null; reasons:string[]; warnings:string[];
 fireSource:{url:string;lastModified:string|null;latestDetection:string|null;recentCount:number;priorCount:number;observationalCoverage:'unknown'}|null;
 satelliteHealth:SatelliteSourceHealth|null;
 featureCoverage:{completeCells:number;totalCells:number};
};
